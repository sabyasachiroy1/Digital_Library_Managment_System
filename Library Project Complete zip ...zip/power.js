function rules()
{
    confirm
    ("Smoking, eating, sleeping and talking loudly are strictly prohibited in the library\nDocuments taken out of the shelves must be left on the table. Replacing the books on shelves is not encouraged as it may get misplaced.\nA non-member can use the library material on the premises with the permission of the Librarian.\nReaders should not mark, underline, dog-ear, write, tear pages or otherwise damage the library documents.\nNewspapers, magazines and journals must be read only in the library on specific tables and should not be taken to any other reading areas.\nNo library material can be taken out of the library without  permission. Unauthorized removal of anything belonging to the library will be treated as theft and dealt accordingly\nNo library material can be taken out of the library without  permission\nAny  one  who  violates  the  rules  and  regulations  of  the  library  would  be  liable  to  lose  the  privilege  of  library membership and may be debarred from using the library facilities.")


}
function valuetransfers($s)
{
    alert(s);
    
}