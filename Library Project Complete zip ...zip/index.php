<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css">
    <script src="/power.js"></script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
<div class="headingcontainers" style=" background-color:black">
<a href="/index.php"class="headingmains"><strong style="margin-left: 10px; ">BOOK PLUS</strong></a>
<a href="/index.php"><button class="homebuttons" style="margin-left: 45px;">Home</button></a>
<a href="/About.html"><button class="homebuttons">About Us</button></a>
<a href="" ><button class="homebuttons" onclick="rules()">Rules</button></a>
<a href="/support.php"><button class="homebuttons">Contact Us</button></a>
<a href="/login.php"><button class="homebuttons" id="loginbutton">Login</button></a>
<a href="/signup.php"><button class="homebuttons" id="signupbutton">Signup</button></a>
</div>
<div class="bodyimagesections">
<img src="/libraryphpoto.jpg" style="height: 72vh;width:99%;overflow:auto;"> 
</div>
<div class="footersections">
<div class="imageparts">
    <img src="/library.jpg" style="width: 25%;">
</div>
<div class="sectionsparts" >
    <ul type="square">
     <li><a href="/index.php" class="homebuttonset">Home</a></li>
     <li><a href="/support.php" class="homebuttonset">Contact Us</a></li>
     <li><a href="/login.php" class="homebuttonset">Admin</a></li>
     <li><a href="/support.php" class="homebuttonset">Report</a></li>  <li><a href="" class="homebuttonset">All Right Reserved</a></li>
    </ul>
    <marquee style="color: red;">
        <h3> Library Opens (6.30 am - 11.30 pm)</h3>
    </marquee>
</div>
</div>
</body>
</html>